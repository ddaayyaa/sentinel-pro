import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class MultiFaceDetectionScreen extends StatelessWidget {
  const MultiFaceDetectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F9),
      body: Stack(
        children: [
          // Header
          Positioned(
            top: 60,
            left: 24,
            child: Row(
              children: [
                GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back, color: AppTheme.textDark, size: 28)),
                const SizedBox(width: 20),
                const Text('Multi-Face Detection', style: TextStyle(color: AppTheme.textDark, fontSize: 20, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          // Multi Frames
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildDetectionFrame('Person 1', const Color(0xFF10B981)),
                const SizedBox(width: 24),
                _buildDetectionFrame('Person 2', const Color(0xFF10B981)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetectionFrame(String name, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(6)),
          child: Text(name, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 8),
        Container(
          width: 140,
          height: 180,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color, width: 2),
          ),
        ),
      ],
    );
  }
}
