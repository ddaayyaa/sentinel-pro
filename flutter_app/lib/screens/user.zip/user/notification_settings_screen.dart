import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class NotificationSettingsScreen extends StatelessWidget {
  const NotificationSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: AppTheme.textDark), onPressed: () => Navigator.pop(context)),
        title: const Text('Notifications', style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE5E7EB))),
            child: Column(
              children: [
                _buildSwitchTile('Push Notifications', 'Receive push notifications', true),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('Email Alerts', 'Get email notifications', true),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('SMS Alerts', 'Receive SMS notifications', false),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('Security Alerts', 'Critical security notifications', true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String sub, bool val) {
    return ListTile(
      leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.primaryPurple.withOpacity(0.1), shape: BoxShape.circle), child: const Icon(Icons.notifications_none_rounded, color: AppTheme.primaryPurple, size: 20)),
      title: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      subtitle: Text(sub, style: const TextStyle(fontSize: 12, color: AppTheme.textLight)),
      trailing: Switch(value: val, onChanged: (v) {}, activeColor: AppTheme.primaryPurple),
    );
  }
}
