import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class RaiseTicketScreen extends StatelessWidget {
  const RaiseTicketScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Raise Ticket',
          style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Subject', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppTheme.textLight)),
            const SizedBox(height: 8),
            _buildTextField('Enter ticket subject'),
            
            const SizedBox(height: 24),
            
            const Text('Description', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppTheme.textLight)),
            const SizedBox(height: 8),
            _buildTextField('Describe your issue...', maxLines: 5),
            
            const SizedBox(height: 20),
            
            TextButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.attachment_rounded, color: AppTheme.primaryPurple, size: 18),
              label: const Text('Attach Files', style: TextStyle(color: AppTheme.primaryPurple, fontWeight: FontWeight.bold)),
              style: TextButton.styleFrom(alignment: Alignment.centerLeft, padding: EdgeInsets.zero),
            ),
            
            const SizedBox(height: 48),
            
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(colors: [Color(0xFF7B61FF), Color(0xFF9E8AFF)]),
              ),
              child: ElevatedButton(
                onPressed: () => Navigator.pushReplacementNamed(context, '/thank-you'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  minimumSize: const Size(double.infinity, 56),
                ),
                child: const Text('Submit Ticket'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String hint, {int maxLines = 1}) {
    return TextField(
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE5E7EB))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE5E7EB))),
      ),
    );
  }
}
