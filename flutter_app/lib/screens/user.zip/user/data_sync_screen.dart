import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../../theme/app_theme.dart';

class DataSyncScreen extends StatefulWidget {
  const DataSyncScreen({super.key});

  @override
  State<DataSyncScreen> createState() => _DataSyncScreenState();
}

class _DataSyncScreenState extends State<DataSyncScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: AppTheme.textDark), onPressed: () => Navigator.pop(context)),
        title: const Text('Data Sync', style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE5E7EB))),
              child: Column(
                children: [
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (_, child) => Transform.rotate(angle: _controller.value * 2 * math.pi, child: child),
                    child: const Icon(Icons.sync_rounded, size: 64, color: AppTheme.primaryPurple),
                  ),
                  const SizedBox(height: 24),
                  const Text('Syncing Data...', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                  const SizedBox(height: 8),
                  const Text('Please wait while we sync your data', style: TextStyle(color: AppTheme.textLight, fontSize: 13)),
                  const SizedBox(height: 24),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: const LinearProgressIndicator(value: 0.85, minHeight: 8, backgroundColor: Color(0xFFF3F4F6), valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryPurple)),
                  ),
                  const SizedBox(height: 12),
                  const Text('85% Complete', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppTheme.textLight)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE5E7EB))),
              child: Row(
                children: const [
                  Icon(Icons.access_time_rounded, color: AppTheme.textLight, size: 20),
                  SizedBox(width: 12),
                  Text('Last Sync:', style: TextStyle(fontSize: 14, color: AppTheme.textLight)),
                  Spacer(),
                  Text('2 minutes ago', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
