import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class PrivacySettingsScreen extends StatelessWidget {
  const PrivacySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: AppTheme.textDark), onPressed: () => Navigator.pop(context)),
        title: const Text('Privacy Settings', style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE5E7EB))),
            child: Column(
              children: [
                _buildSwitchTile('Data Usage', 'Control how your data is used', true),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('Face Data Storage', 'Store face recognition data', true),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('Location Access', 'Allow location tracking', false),
                const Divider(height: 1, indent: 64, color: Color(0xFFF3F4F6)),
                _buildSwitchTile('Analytics', 'Share anonymous usage data', true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(String title, String sub, bool val) {
    return ListTile(
      leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.primaryPurple.withOpacity(0.1), shape: BoxShape.circle), child: const Icon(Icons.privacy_tip_outlined, color: AppTheme.primaryPurple, size: 20)),
      title: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      subtitle: Text(sub, style: const TextStyle(fontSize: 12, color: AppTheme.textLight)),
      trailing: Switch(value: val, onChanged: (v) {}, activeColor: AppTheme.primaryPurple),
    );
  }
}
