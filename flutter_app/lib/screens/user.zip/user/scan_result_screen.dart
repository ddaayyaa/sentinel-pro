import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class ScanResultScreen extends StatelessWidget {
  final bool isGranted;
  final String name;
  final double confidence;
  final String timestamp;
  final String location;

  const ScanResultScreen({
    super.key,
    required this.isGranted,
    this.name = 'John Anderson',
    this.confidence = 98.7,
    this.timestamp = '15:01:18',
    this.location = 'Main Entrance',
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = isGranted ? const Color(0xFF10B981) : const Color(0xFFEF4444);
    final statusIcon = isGranted ? Icons.check_circle_outline_rounded : Icons.cancel_outlined;
    final statusText = isGranted ? 'Access Granted' : 'Access Denied';
    final subtitleText = isGranted ? 'Identity verified successfully' : 'Unauthorized person detected';

    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Scan Result',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const SizedBox(height: 40),
              // Status Icon with Glow
              Center(
                child: Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: statusColor.withOpacity(0.15),
                        blurRadius: 40,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    statusIcon,
                    size: 100,
                    color: statusColor,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              // Status Title
              Text(
                statusText,
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
              const SizedBox(height: 8),
              // Subtitle
              Text(
                subtitleText,
                style: const TextStyle(
                  fontSize: 16,
                  color: AppTheme.textLight,
                ),
              ),
              const SizedBox(height: 40),
              // Data Card
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.02),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    if (!isGranted) ...[
                      Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text(
                              'Security alert has been triggered',
                              style: TextStyle(
                                color: Colors.orange,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],
                    _buildDataRow(
                      isGranted ? 'Name' : 'Status',
                      isGranted ? name : 'Not Recognized',
                      valueColor: isGranted ? AppTheme.textDark : statusColor,
                    ),
                    const Divider(height: 32, color: Color(0xFFF3F4F6)),
                    _buildDataRow('Confidence', '${confidence.toStringAsFixed(1)}%', valueColor: isGranted ? statusColor : AppTheme.textDark),
                    const Divider(height: 32, color: Color(0xFFF3F4F6)),
                    _buildDataRow('Timestamp', timestamp),
                    const Divider(height: 32, color: Color(0xFFF3F4F6)),
                    _buildDataRow('Location', location),
                  ],
                ),
              ),
              const Spacer(),
              // Actions
              if (!isGranted) ...[
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFEF4444),
                    minimumSize: const Size(double.infinity, 56),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Report Issue'),
                ),
                const SizedBox(height: 16),
              ],
              if (isGranted)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF7B61FF), Color(0xFF9E8AFF)],
                    ),
                  ),
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushReplacementNamed(context, '/user-dashboard'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      minimumSize: const Size(double.infinity, 56),
                    ),
                    child: const Text('Back to Dashboard'),
                  ),
                )
              else
                OutlinedButton(
                  onPressed: () => Navigator.pushReplacementNamed(context, '/user-dashboard'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 56),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    side: const BorderSide(color: Color(0xFFE5E7EB)),
                  ),
                  child: const Text('Back to Dashboard', style: TextStyle(color: AppTheme.textDark)),
                ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDataRow(String label, String value, {Color? valueColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 15,
            color: AppTheme.textLight,
            fontWeight: FontWeight.w500,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 15,
            color: valueColor ?? AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
