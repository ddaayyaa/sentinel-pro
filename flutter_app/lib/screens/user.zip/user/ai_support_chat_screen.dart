import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../theme/app_theme.dart';

class AISupportChatScreen extends StatefulWidget {
  final String mode; // 'chat' or 'email'
  const AISupportChatScreen({super.key, this.mode = 'chat'});

  @override
  State<AISupportChatScreen> createState() => _AISupportChatScreenState();
}

class _AISupportChatScreenState extends State<AISupportChatScreen> {
  final List<Map<String, dynamic>> _messages = [];
  final TextEditingController _controller = TextEditingController();
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _addBotMessage(widget.mode == 'email' 
      ? "Hello! I am your AI Assistant. How can I help you draft your support email today?"
      : "Hello! I am the Sentinel Pro AI Assistant. Ask me anything about the system or facial recognition technology!");
  }

  void _addBotMessage(String text) {
    setState(() {
      _messages.insert(0, {'text': text, 'isMe': false});
    });
  }

  void _handleSend() {
    if (_controller.text.trim().isEmpty) return;
    final userText = _controller.text;
    setState(() {
      _messages.insert(0, {'text': userText, 'isMe': true});
      _isTyping = true;
    });
    _controller.clear();

    // AI Simulation Logic
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      String response = "I'm processing your request. Our support team has been notified.";
      
      if (userText.toLowerCase().contains('scan')) {
        response = "To scan a face, ensure the person is within the green frame and in good lighting. Tap the shutter button to begin processing.";
      } else if (userText.toLowerCase().contains('upload')) {
        response = "You can upload JPG, PNG, or WEBP images. Use the 'Bulk Upload' feature for processing multiple faces at once.";
      } else if (userText.toLowerCase().contains('password')) {
        response = "If you've forgotten your password, use the 'Forgot Password' link on the login screen to receive a secure reset code.";
      }

      setState(() {
        _isTyping = false;
        _addBotMessage(response);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppTheme.primaryPurple.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.auto_awesome, color: AppTheme.primaryPurple, size: 18),
            ),
            const SizedBox(width: 12),
            const Text(
              'Security Assistant AI',
              style: TextStyle(color: AppTheme.textDark, fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(20),
              itemCount: _messages.length,
              itemBuilder: (context, index) => _buildMessage(_messages[index]),
            ),
          ),
          if (_isTyping)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Row(
                children: [
                  const Text('AI is thinking', style: TextStyle(fontSize: 12, color: AppTheme.textLight)),
                  const SizedBox(width: 8),
                  const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)),
                ],
              ).animate().fadeIn(),
            ),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildMessage(Map<String, dynamic> msg) {
    final bool isMe = msg['isMe'];
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isMe ? AppTheme.primaryPurple : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isMe ? 20 : 0),
            bottomRight: Radius.circular(isMe ? 0 : 20),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10),
          ],
          border: isMe ? null : Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Text(
          msg['text'],
          style: TextStyle(
            color: isMe ? Colors.white : AppTheme.textDark,
            fontSize: 14,
            height: 1.4,
          ),
        ),
      ),
    ).animate().fadeIn(duration: 300.ms).slideX(begin: isMe ? 0.1 : -0.1);
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE5E7EB))),
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextField(
                  controller: _controller,
                  decoration: const InputDecoration(
                    hintText: 'Ask your question...',
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              decoration: const BoxDecoration(
                color: AppTheme.primaryPurple,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                onPressed: _handleSend,
                icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
