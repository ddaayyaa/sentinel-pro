import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class FaceDetectionScreen extends StatelessWidget {
  const FaceDetectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F9),
      body: Stack(
        children: [
          // Header
          Positioned(
            top: 60,
            left: 24,
            child: Row(
              children: [
                GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back, color: AppTheme.textDark, size: 28)),
                const SizedBox(width: 20),
                const Text('Face Detection', style: TextStyle(color: AppTheme.textDark, fontSize: 20, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          // Detection Frame
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Identification Label
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(color: AppTheme.primaryPurple, borderRadius: BorderRadius.circular(8)),
                  child: const Text('John Anderson', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 12),
                // Square Frame
                Container(
                  width: 240,
                  height: 280,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppTheme.primaryPurple, width: 2),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
