import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class AdminCameraScreen extends StatelessWidget {
  const AdminCameraScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F9),
      body: Stack(
        children: [
          // Camera Preview Area
          Center(
            child: Icon(Icons.camera_alt_outlined, size: 80, color: AppTheme.textDark.withOpacity(0.3)),
          ),
          // Side Controls
          Positioned(
            right: 24,
            top: 60,
            child: Column(
              children: [
                _buildCircleIcon(Icons.flash_off_rounded),
                const SizedBox(height: 20),
                _buildCircleIcon(Icons.switch_camera_rounded),
                const SizedBox(height: 20),
                _buildCircleIcon(Icons.grid_view_rounded),
              ],
            ),
          ),
          // Back Button
          Positioned(
            left: 24,
            top: 60,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.arrow_back, color: AppTheme.textDark, size: 28),
            ),
          ),
          // Shutter Button
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                width: 84,
                height: 84,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 4),
                  boxShadow: [
                    BoxShadow(color: AppTheme.primaryPurple.withOpacity(0.3), blurRadius: 20, spreadRadius: 5),
                  ],
                ),
                child: Container(
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [Color(0xFF7B61FF), Color(0xFF9E8AFF)]),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleIcon(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
      child: Icon(icon, color: AppTheme.textDark, size: 24),
    );
  }
}
