import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class ApiStatusScreen extends StatelessWidget {
  const ApiStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'API Status',
          style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          _buildApiTile('Face Recognition API', 'online', '22ms'),
          _buildApiTile('Database API', 'online', '12ms'),
          _buildApiTile('Authentication API', 'online', '35ms'),
          _buildApiTile('Storage API', 'offline', '-'),
        ],
      ),
    );
  }

  Widget _buildApiTile(String name, String status, String latency) {
    final bool isOnline = status == 'online';
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: (isOnline ? const Color(0xFF10B981) : const Color(0xFFEF4444)).withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(isOnline ? Icons.check_circle_outline_rounded : Icons.cancel_outlined, color: isOnline ? const Color(0xFF10B981) : const Color(0xFFEF4444), size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppTheme.textDark)),
                Text(latency, style: const TextStyle(fontSize: 12, color: AppTheme.textLight)),
              ],
            ),
          ),
          Text(status.toUpperCase(), style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: isOnline ? const Color(0xFF10B981) : const Color(0xFFEF4444))),
        ],
      ),
    );
  }
}
