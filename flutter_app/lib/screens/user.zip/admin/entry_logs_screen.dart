import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class EntryLogsScreen extends StatelessWidget {
  const EntryLogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Entry Logs',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.filter_list, color: AppTheme.textDark), onPressed: () {}),
          IconButton(icon: const Icon(Icons.download_rounded, color: AppTheme.textDark), onPressed: () {}),
          const SizedBox(width: 8),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(24),
        itemCount: 10,
        itemBuilder: (context, index) {
          final isGranted = index % 2 != 0;
          return _buildLogCard(context, index + 1, isGranted);
        },
      ),
    );
  }

  Widget _buildLogCard(BuildContext context, int id, bool isGranted) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/log-details'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Person $id',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.textDark),
                ),
                const SizedBox(height: 4),
                Text(
                  '${10 + id}:30 AM',
                  style: const TextStyle(color: AppTheme.textLight, fontSize: 13),
                ),
              ],
            ),
            Text(
              isGranted ? 'Granted' : 'Denied',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isGranted ? const Color(0xFF10B981) : const Color(0xFFEF4444),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
