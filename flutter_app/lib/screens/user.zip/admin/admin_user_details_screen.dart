import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class AdminUserDetailsScreen extends StatelessWidget {
  const AdminUserDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'User Details',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Profile Header
            const Center(
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Color(0xFFF3F4F6),
                child: Icon(Icons.person, color: Colors.grey, size: 50),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Alice Johnson',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppTheme.textDark,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'User',
              style: TextStyle(
                fontSize: 14,
                color: AppTheme.textLight,
              ),
            ),
            const SizedBox(height: 40),
            // Information Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Column(
                children: [
                  _buildDetailRow(Icons.mail_outline_rounded, 'Email', 'alice@example.com'),
                  const Divider(height: 32, color: Color(0xFFF3F4F6)),
                  _buildDetailRow(Icons.phone_outlined, 'Phone', '+1 555 1234'),
                  const Divider(height: 32, color: Color(0xFFF3F4F6)),
                  _buildDetailRow(Icons.calendar_today_rounded, 'Joined', 'Jan 15, 2024'),
                  const Divider(height: 32, color: Color(0xFFF3F4F6)),
                  _buildDetailRow(Icons.stacked_line_chart_rounded, 'Total Scans', '42'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.primaryPurple, size: 20),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: AppTheme.textLight,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: AppTheme.textDark,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
