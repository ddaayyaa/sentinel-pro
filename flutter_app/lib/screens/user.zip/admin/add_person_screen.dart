import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class AddPersonScreen extends StatelessWidget {
  const AddPersonScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Add Person',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Full Name',
              style: TextStyle(fontSize: 14, color: AppTheme.textLight, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            _buildTextField('Enter name'),
            
            const SizedBox(height: 24),
            
            const Text(
              'ID Number',
              style: TextStyle(fontSize: 14, color: AppTheme.textLight, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            _buildTextField('Enter ID'),
            
            const SizedBox(height: 24),
            
            const Text(
              'Upload Photos',
              style: TextStyle(fontSize: 14, color: AppTheme.textLight, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            Container(
              height: 180,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.upload_rounded, color: AppTheme.primaryPurple, size: 32),
                  const SizedBox(height: 12),
                  const Text(
                    'Upload multiple face images',
                    style: TextStyle(color: AppTheme.textLight, fontSize: 13),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 48),
            
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(
                  colors: [Color(0xFF7B61FF), Color(0xFF9E8AFF)],
                ),
              ),
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  minimumSize: const Size(double.infinity, 56),
                ),
                child: const Text('Add to Database'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String hint) {
    return TextField(
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
    );
  }
}
