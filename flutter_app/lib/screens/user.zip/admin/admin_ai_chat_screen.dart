import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../theme/app_theme.dart';

class AdminAIChatScreen extends StatefulWidget {
  const AdminAIChatScreen({super.key});

  @override
  State<AdminAIChatScreen> createState() => _AdminAIChatScreenState();
}

class _AdminAIChatScreenState extends State<AdminAIChatScreen> {
  final List<Map<String, dynamic>> _messages = [];
  final TextEditingController _controller = TextEditingController();
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _addBotMessage("Greetings, Administrator. I am the Sentinel Pro Core AI. I have full access to system documentation and security protocols. How can I assist you in managing the network today?");
  }

  void _addBotMessage(String text) {
    setState(() {
      _messages.insert(0, {'text': text, 'isMe': false});
    });
  }

  void _handleSend() {
    if (_controller.text.trim().isEmpty) return;
    final userText = _controller.text;
    setState(() {
      _messages.insert(0, {'text': userText, 'isMe': true});
      _isTyping = true;
    });
    _controller.clear();

    // Advanced Admin AI Logic
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      String response = "I've analyzed your query. For security reasons, please refer to the 'Audit Logs' for specific event details or 'System Settings' to modify core parameters.";
      
      final query = userText.toLowerCase();
      if (query.contains('add user') || query.contains('register')) {
        response = "To add a new authorized person, navigate to the 'Face Database' and tap the '+' icon. Ensure you have at least 5 high-quality images for optimal recognition accuracy.";
      } else if (query.contains('alert') || query.contains('breach')) {
        response = "In the event of an unauthorized access alert, I recommend checking the 'Live Monitoring' feeds immediately. You can manually lock down specific sectors from the 'Security Zones' screen.";
      } else if (query.contains('accuracy') || query.contains('threshold')) {
        response = "To improve recognition accuracy, you should increase the 'Confidence Threshold' in System Settings. A value of 0.85 is recommended for high-security areas.";
      } else if (query.contains('backup') || query.contains('data')) {
        response = "Database backups are performed automatically every 24 hours. You can trigger a manual snapshot from the 'Backup & Restore' screen in your advanced tools menu.";
      } else if (query.contains('role') || query.contains('permission')) {
        response = "User permissions are managed via 'Role Management'. You can define access levels for Standard Users vs specialized Security Guards there.";
      } else if (query.contains('report') || query.contains('export')) {
        response = "You can generate detailed PDF or Word audit reports from the 'Report Generator'. These reports include all scan events, alerts, and manual overrides.";
      } else if (query.contains('status') || query.contains('health')) {
        response = "System analysis complete: 4 active streams, 99.9% API uptime, and 1 pending user approval. Security posture is currently: STABLE.";
      }

      setState(() {
        _isTyping = false;
        _addBotMessage(response);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.primaryPurple.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.admin_panel_settings_rounded, color: AppTheme.primaryPurple, size: 20),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Admin Core AI', style: TextStyle(color: AppTheme.textDark, fontSize: 16, fontWeight: FontWeight.bold)),
                Text('System Level Access', style: TextStyle(color: Color(0xFF10B981), fontSize: 10, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(20),
              itemCount: _messages.length,
              itemBuilder: (context, index) => _buildMessage(_messages[index]),
            ),
          ),
          if (_isTyping)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Row(
                children: [
                  const Text('Core AI is analyzing', style: TextStyle(fontSize: 11, color: AppTheme.textLight, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  const SizedBox(width: 10, height: 10, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation(AppTheme.primaryPurple))),
                ],
              ).animate().fadeIn(),
            ),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildMessage(Map<String, dynamic> msg) {
    final bool isMe = msg['isMe'];
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        decoration: BoxDecoration(
          color: isMe ? AppTheme.primaryPurple : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isMe ? 20 : 0),
            bottomRight: Radius.circular(isMe ? 0 : 20),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4)),
          ],
          border: isMe ? null : Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Text(
          msg['text'],
          style: TextStyle(
            color: isMe ? Colors.white : AppTheme.textDark,
            fontSize: 14,
            height: 1.5,
          ),
        ),
      ),
    ).animate().fadeIn(duration: 300.ms).slideX(begin: isMe ? 0.05 : -0.05);
  }

  Widget _buildInput() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE5E7EB))),
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextField(
                  controller: _controller,
                  style: const TextStyle(fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Enter system command or query...',
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              decoration: const BoxDecoration(
                color: AppTheme.primaryPurple,
                shape: BoxShape.circle,
              ),
              child: IconButton(
                onPressed: _handleSend,
                icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
