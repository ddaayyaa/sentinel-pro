import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class RoleManagementScreen extends StatelessWidget {
  const RoleManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Role Management',
          style: TextStyle(color: AppTheme.textDark, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          _buildRoleCard(
            'Admin',
            '5 users',
            ['Full Access', 'User Management', 'System Config'],
            Icons.admin_panel_settings_outlined,
          ),
          const SizedBox(height: 24),
          _buildRoleCard(
            'User',
            '1,234 users',
            ['Face Scan', 'View Results'],
            Icons.person_outline_rounded,
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCard(String role, String userCount, List<String> permissions, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppTheme.primaryPurple, size: 28),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(role, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                  Text(userCount, style: const TextStyle(fontSize: 13, color: AppTheme.textLight)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Divider(color: Color(0xFFF3F4F6)),
          const SizedBox(height: 16),
          ...permissions.map((p) => Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Row(
              children: [
                const Icon(Icons.check_circle_outline_rounded, size: 14, color: Color(0xFF10B981)),
                const SizedBox(width: 8),
                Text(p, style: const TextStyle(fontSize: 14, color: AppTheme.textLight)),
              ],
            ),
          )),
        ],
      ),
    );
  }
}
