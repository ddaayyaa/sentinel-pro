import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class SecurityAlertsScreen extends StatelessWidget {
  const SecurityAlertsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Security Alerts',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          _buildAlertCard(
            context,
            Icons.warning_amber_rounded,
            const Color(0xFFEF4444),
            'Unauthorized Access',
            '5 min ago',
            isResolved: false,
          ),
          _buildAlertCard(
            context,
            Icons.warning_amber_rounded,
            Colors.orange,
            'Failed Scan Attempt',
            '12 min ago',
            isResolved: false,
          ),
          _buildAlertCard(
            context,
            Icons.warning_amber_rounded,
            Colors.orange,
            'System Warning',
            '1 hour ago',
            isResolved: true,
          ),
        ],
      ),
    );
  }

  Widget _buildAlertCard(BuildContext context, IconData icon, Color color, String title, String time, {required bool isResolved}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.textDark,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  time,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppTheme.textLight,
                  ),
                ),
              ],
            ),
          ),
          if (isResolved)
            const Icon(Icons.check_circle_outline_rounded, color: Color(0xFF10B981), size: 24)
          else
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFEF4444),
                minimumSize: const Size(80, 40),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Resolve', style: TextStyle(fontSize: 13)),
            ),
        ],
      ),
    );
  }
}
