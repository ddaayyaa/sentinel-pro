import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class LogDetailsScreen extends StatelessWidget {
  const LogDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Log Details',
          style: TextStyle(
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Face Placeholder
            Container(
              height: 240,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(Icons.person, size: 80, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            // Info Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFE5E7EB)),
              ),
              child: Column(
                children: [
                  _buildDetailRow(Icons.person_outline, 'Person', 'John Anderson'),
                  const Divider(height: 32, color: Color(0xFFF3F4F6)),
                  _buildDetailRow(Icons.access_time_rounded, 'Timestamp', '01/05/2026, 15:15:02'),
                  const Divider(height: 32, color: Color(0xFFF3F4F6)),
                  _buildDetailRow(Icons.location_on_outlined, 'Location', 'Main Entrance'),
                ],
              ),
            ),
            const SizedBox(height: 32),
            // Manual Override Button (Links to Screen 31)
            OutlinedButton(
              onPressed: () => Navigator.pushNamed(context, '/manual-override'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 56),
                side: const BorderSide(color: AppTheme.primaryPurple),
              ),
              child: const Text('Check Override Options', style: TextStyle(color: AppTheme.primaryPurple)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.primaryPurple, size: 20),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textLight)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppTheme.textDark)),
          ],
        ),
      ],
    );
  }
}
